ProvisionsChalutier 1.0.3
=============

[![Esoui Prov's Chalutier page](https://img.shields.io/badge/esoui.com-Provision%27s%20Chalutier-green.svg)](https://www.esoui.com/downloads/info2203-ProvisionsChalutierFishing.html)

Chalutier is a user Interface for The Elder Scrolls Online, designed to show fishing statement :

 - maroon : You are not fishing ; 😴
 - steelblue : You are fishing ;  ⛵ RGB(75, 156, 213)
 - limegreen : You got a fish ! You have to caught it ! 🎣 RGB(0, 204, 0) 
 - maroon : You caught it ! 💰 RGB(101, 69, 0)
