ProvCha =
{
	name = "ProvisionsChalutier",
	namePublic = "Prov's Chalutier",
	nameColor = "|c3BC6DCChalutier|r",
	author = "|c00C000Provision|r",
	version = "1.0.3", --4 endroits
	CPL = nil,
	defaults =
	{ --Don't forget header.lua
		enabled		= true,

		posx		= GuiRoot:GetWidth() / 2 - 485,
		posy		= 0
	}
}
